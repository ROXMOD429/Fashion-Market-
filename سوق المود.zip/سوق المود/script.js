// تسجيل الدخول
function login() {
  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;
  const msg = document.getElementById("msg");

  if (email === "ROXMOD" && password === "123456") {
    localStorage.setItem("isOwner", "true");
    window.location.href = "home.html";
  } else {
    msg.innerHTML = "بيانات الدخول غير صحيحة ❌";
    msg.style.color = "red";
  }
}

// إضافة عنصر جديد (لعبة أو تطبيق)
function addItem() {
  const type = document.getElementById("type").value;
  const name = document.getElementById("name").value;
  const image = document.getElementById("image").value;
  const link = document.getElementById("link").value;
  const desc = document.getElementById("desc").value;

  if (!name || !image || !link) {
    alert("يرجى ملء جميع الحقول!");
    return;
  }

  const newItem = { name, image, link, desc };

  let items = JSON.parse(localStorage.getItem(type)) || [];
  items.push(newItem);
  localStorage.setItem(type, JSON.stringify(items));

  alert("✅ تم رفع العنصر بنجاح!");
  showItems(type);
}

// عرض العناصر في صفحة المالك
function showItems(type) {
  const container = document.getElementById("content");
  if (!container) return;

  const items = JSON.parse(localStorage.getItem(type)) || [];
  container.innerHTML = items.map(i => `
    <div class="item">
      <img src="${i.image}" alt="">
      <h3>${i.name}</h3>
      <p>${i.desc || ""}</p>
      <a href="${i.link}" target="_blank">⬇️ تحميل</a>
    </div>
  `).join("");
}

// عرض حسب الفئة في index
function showCategory(cat) {
  const items = JSON.parse(localStorage.getItem(cat)) || [];
  const container = document.getElementById("content");
  container.innerHTML = items.map(i => `
    <div class="item">
      <img src="${i.image}" alt="">
      <h3>${i.name}</h3>
      <p>${i.desc || ""}</p>
      <a href="${i.link}" target="_blank">⬇️ تحميل</a>
    </div>
  `).join("");
}

// البحث
function searchItems() {
  const text = document.getElementById("search").value.toLowerCase();
  const all = [...(JSON.parse(localStorage.getItem("games")) || []), ...(JSON.parse(localStorage.getItem("apps")) || [])];
  const result = all.filter(i => i.name.toLowerCase().includes(text));

  const container = document.getElementById("content");
  container.innerHTML = result.map(i => `
    <div class="item">
      <img src="${i.image}" alt="">
      <h3>${i.name}</h3>
      <p>${i.desc || ""}</p>
      <a href="${i.link}" target="_blank">⬇️ تحميل</a>
    </div>
  `).join("");
}